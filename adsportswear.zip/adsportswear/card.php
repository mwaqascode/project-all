<section class="mtxl">
    <div class="container sub-tittle">
        <h1>OUR <span>BLOGS</span></h1>
    </div>

    <div class="album ">
        <div class="container">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <div class="col">
                    <div class="card shadow-sm">
                        <img src="photo/blog1.png" alt="">

                        <div class="card-body news_and_event">
                            <h2>MEET US at JDIQ MONTREAL,  BOOTH # 1901</h2>
                            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been theindustry's standard dummy text ever since the 1500s, when an</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-dark">MORE DETAILS</button>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card shadow-sm">
                        <img src="photo/blog2.png" alt="">

                        <div class="card-body news_and_event">
                            <h2>MEET US at JDIQ MONTREAL,  BOOTH # 1901</h2>
                            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been theindustry's standard dummy text ever since the 1500s, when an</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-dark">MORE DETAILS</button>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card shadow-sm">
                        <img src="photo/blog3.png" alt="">

                        <div class="card-body news_and_event">
                            <h2>MEET US at JDIQ MONTREAL,  BOOTH # 1901</h2>
                            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been theindustry's standard dummy text ever since the 1500s, when an</p>

                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-dark">MORE DETAILS</button>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </div>
</section>