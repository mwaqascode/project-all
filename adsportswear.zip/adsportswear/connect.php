

<?php
$con=mysqli_connect('localhost','root','','adwebsite');
if(!$con){
    die("mysqli_error($con)");
}


?>