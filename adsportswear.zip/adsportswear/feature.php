<div class="container p-0">
        <div class="row">
               <div class="col-12 col-sm-6 col-md-4 col-lg-3 mt-4">
                   <div class="card" style="width: 17rem;">
                           <img class="card-img-top" src="photo/img 1.jpg" alt="">
                           <div class="card-body text-center">
                            <div class="card-tittle">Hoodie</div>
                            <div class="card-number">ES:2105</div>
                                
                           </div>
                   </div>

               </div>
               <div class="col-12 col-sm-6 col-md-4 col-lg-3 mt-4">
                   <div class="card" style="width: 17rem;">
                           <img class="card-img-top" src="photo/img 2.jpg" alt="">
                           <div class="card-body text-center">
                            <div class="card-tittle">Hoodie</div>
                            <div class="card-number">ES:2105</div>
                                
                           </div>
                   </div>

               </div>
               <div class="col-12 col-sm-6 col-md-4 col-lg-3 mt-4">
                   <div class="card" style="width: 17rem;">
                           <img class="card-img-top" src="photo/img 3.jpg" alt="">
                           <div class="card-body text-center">
                            <div class="card-tittle">Hoodie</div>
                            <div class="card-number">ES:2105</div>
                                
                           </div>
                   </div>

               </div>
               <div class="col-12 col-sm-6 col-md-4 col-lg-3 mt-4">
                   <div class="card" style="width: 17rem;">
                           <img class="card-img-top" src="photo/img 4.jpg" alt="">
                           <div class="card-body text-center">
                            <div class="card-tittle">Hoodie</div>
                            <div class="card-number">ES:2105</div>
                                
                           </div>
                   </div>

               </div>
               
        </div>

    </div>